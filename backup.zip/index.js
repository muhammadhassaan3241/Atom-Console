        // {
        //     "destination": "Unknown",
        //     "total_users": 340
        // },

            // "test": "cross-env NODE_ENV=test mocha --timeout 10000 src/tests/*.test.js --exit",
    // "coverage": "istanbul cover _mocha src/tests/*.test.js --recursive && istanbul report"
  // "start": "node app.js",