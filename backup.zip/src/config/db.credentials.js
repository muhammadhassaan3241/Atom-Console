// db parameters
export const DBHOST = "localhost"
export const DBUSER = "root"
export const DBPASS = ""
export const DBNAME = "Gaditek"